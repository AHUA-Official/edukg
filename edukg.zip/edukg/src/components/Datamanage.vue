<template>
    <div>
        <CalendarManage/>
    </div>
</template>
<script setup>
import CalendarManage from './CalendarManage.vue';

</script>
<style scoped>
</style>