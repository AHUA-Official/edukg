import pdfplumber
import spacy
import pandas as pd

nlp = spacy.load("zh_core_web_sm")
def pdf_switch_csv(file_path,output_file):
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() + "\n"
        doc = nlp(text)
        sentences = [sent.text for sent in doc.sents]
        df = pd.DataFrame({"sentence": sentences})
        df.to_csv(output_file, index=False)

file_path = "./input/simple.pdf"
output_file = "./output/output_sentences5.csv"
pdf_switch_csv(file_path,output_file)
