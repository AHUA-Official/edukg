import re
import spacy
from hanlp_restful import HanLPClient
from combine_with_previous import combine_with_previous
from combine_with_next import combine_with_next

# 初始化HanLP
HanLP = HanLPClient('https://www.hanlp.com/api', auth='YOUR_AUTH_KEY', language='zh')

nlp = spacy.load("zh_core_web_sm")

def extract_triplet(sentence_tokens, sentence_dep):
    subject = ''
    predicate = ''
    object_first = ''
    object_second = ''

    sentence_list = []
    for i, (token, dependency) in enumerate(zip(sentence_tokens, sentence_dep)):
        entry = {'token': token, 'dependency': dependency[1], 'dependency_num': dependency[0]}
        sentence_list.append(entry)

    for i, entry in enumerate(sentence_list):
        if entry['dependency'] == 'root':
            predicate = combine_with_previous(sentence_list, i, ['aux:modal', 'advmod', 'neg', 'xcomp'])
            predicate = combine_with_next(sentence_list, i, predicate, ['aux:modal', 'advmod', 'neg', 'dep'])
        elif entry['dependency'] in ['nsubj', 'nsubjpass']:
            subject = combine_with_previous(sentence_list, i, ['compound:nn', 'mark', 'amod', 'discourse', 'dep'])
        elif entry['dependency'] in ['dobj', 'iobj']:
            object_first = combine_with_previous(sentence_list, i, ['compound:nn', 'mark', 'amod', 'case', 'det'])
        elif entry['dependency'] == 'conj':
            object_second = combine_with_previous(sentence_list, i, ['compound:nn', 'mark', 'amod', 'case'])

    if object_second:
        return [
            (subject, predicate, object_first.strip()),
            (subject, predicate, object_second.strip())
        ]
    return (subject, predicate, object_first.strip())

def extract_triples_from_text(text):
    # 使用HanLP进行依存关系解析
    doc = HanLP.parse(text, tasks='dep')
    tok_fine = doc["tok/fine"]
    dependency_analysis = doc["dep"]

    triples = []
    for sentence_tokens, sentence_dep in zip(tok_fine, dependency_analysis):
        triplet = extract_triplet(sentence_tokens, sentence_dep)
        triples.append(triplet)

    return triples

