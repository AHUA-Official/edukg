
def combine_with_previous(sentence_list, index, target_dep):
    """
    检查某个词的前面词是否具有指定的依存关系（如 compound:nn），
    如果有，则将这些词组合在一起返回。

    :param sentence_list: 词语及其依存关系的列表
    :param index: 当前词的索引
    :param target_dep: 目标依存关系类型（如 compound:nn）
    :return: 组合后的词语
    """
    combined_token = sentence_list[index]['token']

    # 向前检查前面的词是否符合目标依存关系
    j = index - 1
    while j >= 0 and sentence_list[j]['dependency'] in target_dep:
        combined_token = sentence_list[j]['token'] + combined_token
        j -= 1

    return combined_token
