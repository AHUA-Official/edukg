import requests
import json

def fetch_pdf(book_id):
    url = "http://8.137.104.90:8099/reader/getbook"
    headers = {'Content-Type': 'application/json'}
    payload = {"id": book_id} 
    response = requests.post(url, data=json.dumps(payload), headers=headers)
    if response.status_code == 200:
        # 如果响应类型是PDF
        if 'application/pdf' in response.headers.get('content-type', ''):
            # 保存PDF文件
            with open(f"share.pdf", "wb") as f:
                f.write(response.content)
            print(f"PDF saved as share.pdf")
        else:
            print("Unexpected content type received.")
    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")

