import requests
import time
from modelscope import AutoModelForCausalLM, AutoTokenizer
model_path = "qwen/Qwen-1_8B-Chat"
# 加载分词器和模型
tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_path, device_map="cpu", trust_remote_code=True).eval()
history = None
# 获取问题的API地址
get_question_url = "http://8.137.104.90:8099/bigmodel/selectBygenstatus"
# 提交答案的API地址
submit_answer_url = "http://8.137.104.90:8099/bigmodel/returnanswer"
response = requests.get(get_question_url)
question_all = response.json()
# print(question_all['data'])
question_list_initial = [[item['id'], item['questiontext']] for item in question_all['data']]
print(question_list_initial)
for i in range(len(question_list_initial)):
    messages = [
            {"role": "user", "content": question_list_initial[i][1]}
            ]   
            # 生成答案
    text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
            )
    model_inputs = tokenizer([text], return_tensors="pt").to('cpu')
    generated_ids = model.generate(
    model_inputs.input_ids,
    max_new_tokens=512
            )
    generated_ids = [
            output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
            ]
    response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    answer_data = {
            "putid": question_list_initial[i][0],  
            "answer": response
            }
        # 将答案返回给服务器
            # submit_response = requests.post(submit_answer_url, json=answer_data)
    print(f'System: {response}')
    print(question_list_initial[i][0])
while True:
    # 从服务器获取JSON格式的问题
    response = requests.get(get_question_url)
    question_all = response.json()
    question_list_current = [[item['id'], item['questiontext']] for item in question_all['data']]
    print(question_list_current)
    print(len(question_list_current))
    for j in range(len(question_list_current)):
        if question_list_current[j][1] != question_list_initial[j][1] and question_list_current[j][0]:
            messages = [
            {"role": "user", "content": question_list_current[j][1]}
            ]   
            # 生成答案
            text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
            )
            model_inputs = tokenizer([text], return_tensors="pt").to('cpu')
            generated_ids = model.generate(
            model_inputs.input_ids,
            max_new_tokens=512
            )
            generated_ids = [
            output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
            ]
            response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
            answer_data = {
            "putid": question_list_current[j][0],  
            "answer": response
            }
        # 将答案返回给服务器
             submit_response = requests.post(submit_answer_url, json=answer_data)
            print(f'System: {response}')
            question_list_initial[j][1] = question_list_current[j][1]
        else:
            continue
    # 打印生成的答案
    time.sleep(5) 
    # 准备返回给服务器的JSON数据

    # 打印服务器响应
    print(f'Server Response: {submit_response.status_code} - {submit_response.json()}')

    # 根据需要决定是否继续循环
