import requests
import json
import pandas as pd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像时负号 '-' 显示为方块的问题
pd.set_option('display.max_colwidth', 200)

# 提取三元组的URL和请求头
url = 'http://8.137.104.90:8099/triple/add'
headers = {'Content-Type': 'application/json'}

# 遍历多个 PDF 文件
for i in range(9):
    # 获取 PDF 文件并转换为 CSV
    fetch_pdf(str(i))
    pdf_switch_csv('share.pdf', 'share.csv')

    # 读取 CSV 文件，处理不同的编码问题
    try:
        candidate_sentences = pd.read_csv('./share.csv', encoding='utf-8')
    except UnicodeDecodeError:
        candidate_sentences = pd.read_csv('./share.csv', encoding='gbk')

    # 确保 'sentence' 列的数据类型是字符串
    candidate_sentences['sentence'] = candidate_sentences['sentence'].apply(
        lambda x: str(x) if isinstance(x, (int, float)) else x
    )

    # 将 CSV 中的句子拼接为一个文本
    text = ' '.join(candidate_sentences['sentence'].tolist())

    # 使用 extract_triples_from_text 提取三元组
    triples = extract_triples_from_text(text)

    # 遍历三元组并发送 POST 请求
    for triple in triples:
        if isinstance(triple, list):
            # 处理多个宾语的情况
            for sub_triple in triple:
                source, rel, target = sub_triple
                data = {"source": str(source), "target": str(target), "edge": str(rel)}
                response = requests.post(url, data=json.dumps(data), headers=headers)

                if response.status_code == 200:
                    print("请求成功")
                    print("返回的数据:", response.json())
                else:
                    print(f"请求失败，状态码：{response.status_code}")
                    print("错误信息:", response.text)
        else:
            # 处理单个宾语的情况
            source, rel, target = triple
            data = {"source": str(source), "target": str(target), "edge": str(rel)}
            response = requests.post(url, data=json.dumps(data), headers=headers)

            if response.status_code == 200:
                print("请求成功")
                print("返回的数据:", response.json())
            else:
                print(f"请求失败，状态码：{response.status_code}")
                print("错误信息:", response.text)
